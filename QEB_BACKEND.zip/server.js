import express from 'express';
import mongoose from 'mongoose';
import cors from 'cors';
import dotenv from 'dotenv';
dotenv.config();

const app = express();
app.use(cors());
app.use(express.json());

mongoose.connect(process.env.MONGO_URI).then(()=>console.log('DB Connected'));

const userSchema = new mongoose.Schema({
  email: String,
  password: String,
  balance: { type: Number, default: 0 }
});
const User = mongoose.model('User', userSchema);

const depSchema = new mongoose.Schema({
  userId: String,
  amount: Number,
  txid: String,
  status: { type: String, default: 'pending' }
});
const Deposit = mongoose.model('Deposit', depSchema);

const orderSchema = new mongoose.Schema({
  userId: String,
  product: String,
  quantity: Number,
  fileLink: String,
  status: { type: String, default: 'pending' }
});
const Order = mongoose.model('Order', orderSchema);

app.post('/signup', async (req,res)=>{
  const u = await User.create(req.body);
  res.json({success:true,user:u});
});

app.post('/login', async(req,res)=>{
  const u = await User.findOne(req.body);
  if(!u) return res.json({success:false});
  res.json({success:true,user:u});
});

app.post('/deposit', async(req,res)=>{
  const d = await Deposit.create(req.body);
  res.json({success:true,deposit:d});
});

app.post('/deposit/approve', async(req,res)=>{
  const d = await Deposit.findById(req.body.id);
  d.status='approved';
  await d.save();
  const u = await User.findById(d.userId);
  u.balance += d.amount;
  await u.save();
  res.json({success:true});
});

app.post('/order', async(req,res)=>{
  const o = await Order.create(req.body);
  res.json({success:true,order:o});
});

app.post('/order/sendfile', async(req,res)=>{
  const o = await Order.findById(req.body.id);
  o.fileLink = req.body.link;
  o.status = 'completed';
  await o.save();
  res.json({success:true});
});

app.get('/',(req,res)=>res.send('API Running'));

app.listen(3000,()=>console.log('Server running'));